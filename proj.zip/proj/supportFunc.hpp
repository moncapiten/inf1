#ifndef SUPPORTFUNC_HPP
#define SUPPORTFUNC_HPP

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>

using namespace std;

#endif // SUPPORTFUNC_HPP